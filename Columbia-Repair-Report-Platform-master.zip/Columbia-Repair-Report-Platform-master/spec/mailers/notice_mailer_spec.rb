require "rails_helper"

RSpec.describe NoticeMailer, type: :mailer do
end
