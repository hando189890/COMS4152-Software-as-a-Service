class ApplicationMailer < ActionMailer::Base
  default from: "1023990429@qq.com"
  layout 'mailer'
end
